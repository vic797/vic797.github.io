import os

def get_name(filename):
    return os.path.splitext(os.path.basename(filename))[0]

def properties():
    for filename in os.listdir("."):
        if filename.endswith(".png"):
            color = get_name(filename)
            prop = open(color + ".properties", "w")
            prop.write("container=shulker_box\n")
            prop.write("texture=" + color + "\n")
            prop.write("colors=" + color + "\n")
            prop.close()

if __name__ == "__main__":
    properties()